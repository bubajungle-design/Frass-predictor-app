package com.jb.frasspredictor

import kotlin.math.ln
import kotlin.math.log1p
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

data class CropProfile(
    val name: String,
    val baselineBrix: Double,
    val baselineYieldPerPlantLb: Double,
    val baselineUnitSizeG: Double,
    val baselineNDI: Double = 1.0,
    val baselineNDiv: Double = 1.0,
    val reqAreaSqft: Double = 2.0,
    val targetRootingDepthFt: Double = 1.0,
    val sizeUnitsPerPlant: Double = 5.0
)

data class BedSetup(
    val lengthFt: Double,
    val widthFt: Double,
    val depthFt: Double,
    val frassLbs: Double
) {
    val volumeCuFt: Double get() = lengthFt * widthFt * depthFt
    val frassLbPerCuFt: Double get() = frassLbs / max(volumeCuFt, 1e-9)
}

data class Prediction(
    val frassLbPerCuFt: Double,
    val frassFactor: Double,
    val depthFactor: Double,
    val spacingFactor: Double,
    val yieldPerPlantLb: Double,
    val totalYieldLb: Double,
    val brixDeg: Double,
    val nutrientDensityIndex: Double,
    val nutrientDiversityIndex: Double,
    val unitSizeG: Double,
    val unitsPerPlant: Double,
    val areaPerPlantSqft: Double
)

class FrassModel(private val params: MutableMap<String, Double> = defaultParams().toMutableMap()) {

    companion object {
        fun defaultParams(): Map<String, Double> = mapOf(
            "frass_baseline_lb_per_cuft" to 0.5,
            "frass_gain" to 0.35,
            "frass_diminish" to 0.65,
            "overload_threshold" to 2.0,
            "overload_penalty" to 0.12,
            "spacing_elasticity" to 0.35,
            "depth_gamma" to 0.75,
            "brix_from_frass" to 0.28,
            "brix_from_spacing" to 0.12,
            "brix_yield_tradeoff" to -0.08,
            "ndi_from_frass" to 0.40,
            "ndi_dilution_from_yield" to -0.18,
            "ndiv_from_frass_log" to 0.22,
            "size_from_frass" to 0.25,
            "size_from_spacing" to 0.20
        )
    }

    private fun frassFactor(frassLbPerCuFt: Double): Double {
        val x = frassLbPerCuFt / max(params["frass_baseline_lb_per_cuft"]!!, 1e-9)
        var base = 1.0 + params["frass_gain"]!! * ln(1.0 + x).pow(params["frass_diminish"]!!)
        if (frassLbPerCuFt > params["overload_threshold"]!!) {
            val overload = (frassLbPerCuFt - params["overload_threshold"]!!)
            base *= (1.0 - params["overload_penalty"]!! * ln(1.0 + overload))
            base = max(base, 0.5)
        }
        return max(base, 0.0)
    }

    private fun depthFactor(bedDepthFt: Double, targetDepthFt: Double): Double {
        val ratio = min(bedDepthFt / max(targetDepthFt, 1e-6), 1.5)
        return ratio.pow(params["depth_gamma"]!!)
    }

    private fun spacingFactor(bedSqft: Double, plantCount: Int, reqAreaSqft: Double): Double {
        if (plantCount <= 0) return 0.0
        val areaPerPlant = bedSqft / plantCount.toDouble()
        val elasticity = params["spacing_elasticity"]!!
        return if (areaPerPlant >= reqAreaSqft) {
            (areaPerPlant / reqAreaSqft).pow(elasticity)
        } else {
            (areaPerPlant / reqAreaSqft).pow(elasticity * 1.25)
        }
    }

    fun predict(
        crop: CropProfile,
        bed: BedSetup,
        plantCount: Int,
        envFactor: Double = 1.0
    ): Prediction {
        val bedSqft = bed.lengthFt * bed.widthFt
        val frassConc = bed.frassLbPerCuFt

        val F = frassFactor(frassConc)
        val D = depthFactor(bed.depthFt, crop.targetRootingDepthFt)
        val S = spacingFactor(bedSqft, plantCount, crop.reqAreaSqft)

        val yieldPerPlant = crop.baselineYieldPerPlantLb * F * D * S * envFactor
        val totalYield = yieldPerPlant * plantCount

        val brix = crop.baselineBrix * (
            1 + params["brix_from_frass"]!! * (F - 1) +
                params["brix_from_spacing"]!! * (S - 1) +
                params["brix_yield_tradeoff"]!! * ((yieldPerPlant / max(crop.baselineYieldPerPlantLb, 1e-9)) - 1)
            )

        val ndi = crop.baselineNDI * (
            1 + params["ndi_from_frass"]!! * (F - 1) +
                params["ndi_dilution_from_yield"]!! * ((yieldPerPlant / max(crop.baselineYieldPerPlantLb, 1e-9)) - 1)
            )

        val ndiv = crop.baselineNDiv * (1 + params["ndiv_from_frass_log"]!! * ln(1.0 + frassConc))

        val sizeG = crop.baselineUnitSizeG * (
            1 + params["size_from_frass"]!! * (F - 1) +
                params["size_from_spacing"]!! * (S - 1)
            )

        val unitsPerPlant = max(1.0, crop.sizeUnitsPerPlant * (0.9 + 0.15*(F - 1)) * (0.9 + 0.2*(S - 1)))

        return Prediction(
            frassLbPerCuFt = frassConc,
            frassFactor = F,
            depthFactor = D,
            spacingFactor = S,
            yieldPerPlantLb = yieldPerPlant,
            totalYieldLb = totalYield,
            brixDeg = brix,
            nutrientDensityIndex = ndi,
            nutrientDiversityIndex = ndiv,
            unitSizeG = sizeG,
            unitsPerPlant = unitsPerPlant,
            areaPerPlantSqft = if (plantCount > 0) bedSqft / plantCount.toDouble() else 0.0
        )
    }
}

object CropPresets {
    val carrotBlackNebula = CropProfile(
        name = "Carrot (Black Nebula)",
        baselineBrix = 9.0,
        baselineYieldPerPlantLb = 0.5,
        baselineUnitSizeG = 200.0,
        reqAreaSqft = 0.25,
        targetRootingDepthFt = 1.0,
        sizeUnitsPerPlant = 1.0
    )
    val watermelonYellowCrimson = CropProfile(
        name = "Watermelon (Yellow Crimson)",
        baselineBrix = 11.5,
        baselineYieldPerPlantLb = 35.0,
        baselineUnitSizeG = 9000.0,
        reqAreaSqft = 24.0,
        targetRootingDepthFt = 1.5,
        sizeUnitsPerPlant = 3.0
    )
    val honeydewOrangeFlesh = CropProfile(
        name = "Honeydew (Orange Flesh)",
        baselineBrix = 12.0,
        baselineYieldPerPlantLb = 18.0,
        baselineUnitSizeG = 2500.0,
        reqAreaSqft = 12.0,
        targetRootingDepthFt = 1.25,
        sizeUnitsPerPlant = 4.0
    )
    val skirret = CropProfile(
        name = "Skirret",
        baselineBrix = 7.5,
        baselineYieldPerPlantLb = 1.8,
        baselineUnitSizeG = 30.0,
        reqAreaSqft = 1.0,
        targetRootingDepthFt = 1.0,
        sizeUnitsPerPlant = 25.0
    )

    val all = listOf(carrotBlackNebula, watermelonYellowCrimson, honeydewOrangeFlesh, skirret)
}
