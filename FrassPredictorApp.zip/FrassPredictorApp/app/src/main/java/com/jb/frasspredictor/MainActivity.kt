package com.jb.frasspredictor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    FrassPredictorScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FrassPredictorScreen() {
    val model = remember { FrassModel() }
    var cropIndex by remember { mutableStateOf(0) }
    val crops = remember { CropPresets.all }
    var length by remember { mutableStateOf(3.25) }
    var width by remember { mutableStateOf(3.25) }
    var depth by remember { mutableStateOf(2.0) }
    var frass by remember { mutableStateOf(60.0) }
    var plants by remember { mutableStateOf(36.0) }
    var env by remember { mutableStateOf(1.0) }

    val crop = crops[cropIndex]
    val bed = BedSetup(length, width, depth, frass)
    val pred = model.predict(crop, bed, plants.roundToInt(), env)

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Frass Predictor", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Tune your bed, frass, and plant density. Predictions update live.", style = MaterialTheme.typography.bodyMedium)

        Spacer(Modifier.height(16.dp))
        // Crop chooser
        ExposedDropdownMenuBox(
            expanded = false,
            onExpandedChange = {}
        ) {
            OutlinedTextField(
                value = crop.name,
                onValueChange = {},
                label = { Text("Crop") },
                readOnly = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            crops.forEachIndexed { idx, c ->
                AssistChip(
                    onClick = { cropIndex = idx },
                    label = { Text(c.name.substringBefore("(").trim()) },
                    leadingIcon = {},
                    modifier = Modifier.padding(end = 6.dp),
                    enabled = cropIndex != idx
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        // Bed sliders / fields
        LabeledSlider("Bed length (ft)", length, 1.0, 8.0) { length = it }
        LabeledSlider("Bed width (ft)", width, 1.0, 8.0) { width = it }
        LabeledSlider("Bed depth (ft)", depth, 0.5, 3.0) { depth = it }
        LabeledSlider("Frass (lb)", frass, 0.0, 150.0, step = 1.0) { frass = it }
        LabeledSlider("Plant count", plants, 1.0, 100.0, step = 1.0) { plants = it }
        LabeledSlider("Env factor", env, 0.5, 1.5) { env = it }

        Spacer(Modifier.height(8.dp))
        MetricsCard(pred)

        Spacer(Modifier.height(16.dp))
        Text("Brix vs Frass Concentration (lb/ft³)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        BrixChart(model = model, crop = crop, bedLength = length, bedWidth = width, bedDepth = depth, plantCount = plants.roundToInt())
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
fun LabeledSlider(label: String, value: Double, min: Double, max: Double, step: Double = 0.1, onChange: (Double) -> Unit) {
    Text(label, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
    Slider(
        value = value.toFloat(),
        onValueChange = { onChange(it.toDouble()) },
        valueRange = min.toFloat()..max.toFloat(),
        steps = ((max - min) / step - 1).toInt().coerceAtLeast(0)
    )
    Text(String.format("%.2f", value), style = MaterialTheme.typography.labelLarge)
    Spacer(Modifier.height(8.dp))
}

@Composable
fun MetricsCard(pred: Prediction) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("Predictions", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            MetricRow("Frass conc (lb/ft³)", pred.frassLbPerCuFt)
            MetricRow("Area / plant (ft²)", pred.areaPerPlantSqft)
            Divider(Modifier.padding(vertical = 8.dp))
            MetricRow("Brix (°Bx)", pred.brixDeg)
            MetricRow("NDI (rel.)", pred.nutrientDensityIndex)
            MetricRow("NDiv (rel.)", pred.nutrientDiversityIndex)
            Divider(Modifier.padding(vertical = 8.dp))
            MetricRow("Yield / plant (lb)", pred.yieldPerPlantLb)
            MetricRow("Total yield (lb)", pred.totalYieldLb)
            MetricRow("Unit size (g)", pred.unitSizeG)
            MetricRow("Units / plant", pred.unitsPerPlant)
        }
    }
}

@Composable
fun MetricRow(label: String, value: Double) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Text(String.format("%.3f", value), fontWeight = FontWeight.SemiBold)
    }
    Spacer(Modifier.height(4.dp))
}

@Composable
fun BrixChart(model: FrassModel, crop: CropProfile, bedLength: Double, bedWidth: Double, bedDepth: Double, plantCount: Int) {
    val points = remember(bedLength, bedWidth, bedDepth, plantCount) {
        val concs = (0..80).map { it / 20.0 }  // 0..4.0 lb/ft3
        val bedVol = bedLength * bedWidth * bedDepth
        concs.map { c ->
            val bed = BedSetup(bedLength, bedWidth, bedDepth, frassLbs = c * bedVol)
            val p = model.predict(crop, bed, plantCount, 1.0)
            c to p.brixDeg
        }
    }
    val maxBrix = (points.maxOfOrNull { it.second } ?: 1.0)
    val minBrix = (points.minOfOrNull { it.second } ?: 0.0)
    val padding = 10.dp

    Canvas(Modifier.fillMaxWidth().height(180.dp)) {
        val w = size.width
        val h = size.height
        // Axes
        drawRect(color = androidx.compose.ui.graphics.Color.LightGray.copy(alpha = 0.15f), size = Size(w, h))
        // Plot
        val xMax = points.maxOf { it.first }.toFloat()
        val xMin = points.minOf { it.first }.toFloat()
        val yMax = maxBrix.toFloat()
        val yMin = minBrix.toFloat()
        var prev: Offset? = null
        val padX = 24f
        val padY = 20f
        points.forEach { (x, y) ->
            val nx = (x.toFloat() - xMin) / (xMax - xMin + 1e-6f)
            val ny = 1f - ((y.toFloat() - yMin) / (yMax - yMin + 1e-6f))
            val pt = Offset(padX + nx * (w - 2*padX), padY + ny * (h - 2*padY))
            if (prev != null) {
                drawLine(
                    color = androidx.compose.ui.graphics.Color(0xFFFB8C00),
                    start = prev!!,
                    end = pt,
                    strokeWidth = 4f
                )
            }
            prev = pt
        }
    }
}
