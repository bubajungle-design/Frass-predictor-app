/* Top-level build file (empty; configuration handled in app module) */
